﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace RaceDay.MVC.Controllers
{
    public class ParticipantController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ParticipantController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool IsParticipant()
        {
            var role = HttpContext.Session.GetString("UserRole");
            return role == "Participant";
        }

        private HttpClient GetSecureClient()
        {
            var client = _httpClientFactory.CreateClient("RaceDayApi");
            var token = HttpContext.Session.GetString("Token");
            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            return client;
        }

        [HttpGet]
        public async Task<IActionResult> MyEnrolments()
        {
            if (!IsParticipant() || string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var client = GetSecureClient();
            var response = await client.GetAsync("api/enrolments/my-enrolments");

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var enrolments = new List<EnrolmentViewModel>();

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var allEnrolments = JsonSerializer.Deserialize<List<EnrolmentViewModel>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<EnrolmentViewModel>();

                // Filter out any corrupted rows where EventDate defaulted to 01 Jan 0001
                enrolments = allEnrolments
                    .Where(e => e.EventDate.Year > 1900)
                    .ToList();
            }
            else
            {
                ViewBag.Error = "Could not load enrolments. Please try again later.";
            }

            return View(enrolments);
        }

        [HttpGet]
        public async Task<IActionResult> MyRaceHistory()
        {
            if (!IsParticipant() || string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var client = GetSecureClient();
            var response = await client.GetAsync("api/enrolments/my-enrolments");

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var history = new List<EnrolmentViewModel>();

            if (response.IsSuccessStatusCode)
            {
                var json = await response.Content.ReadAsStringAsync();
                var allEnrolments = JsonSerializer.Deserialize<List<EnrolmentViewModel>>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<EnrolmentViewModel>();

                history = allEnrolments
                    .Where(e => e.EventDate.Year > 1900 && e.EventDate < DateTime.Today)
                    .OrderByDescending(e => e.EventDate)
                    .ToList();
            }
            else
            {
                ViewBag.Error = "Could not load race history. Please try again later.";
            }

            return View(history);
        }

        [HttpPost]
        public async Task<IActionResult> Enrol(int eventId, string emergencyContact, string? medicalAidNumber)
        {
            if (!IsParticipant() || string.IsNullOrEmpty(HttpContext.Session.GetString("Token")))
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var client = GetSecureClient();

            // 1. Fetch the event's categories (EventsController auto-creates "General Entry" if none exist yet!)
            int? categoryId = null;
            var categoryResponse = await client.GetAsync($"api/events/{eventId}/categories");
            if (categoryResponse.IsSuccessStatusCode)
            {
                var catJson = await categoryResponse.Content.ReadAsStringAsync();
                var categories = JsonSerializer.Deserialize<List<CategoryViewModel>>(catJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                var defaultCat = categories?.FirstOrDefault();
                if (defaultCat != null)
                {
                    categoryId = defaultCat.CategoryId;
                }
            }

            if (categoryId == null || categoryId == 0)
            {
                TempData["Error"] = "Enrolment failed: Could not link a category for this event.";
                return RedirectToAction("Details", "Events", new { id = eventId });
            }

            // 2. Send the real CategoryId so the database links Enrolment -> Category -> Event!
            var payload = new
            {
                EventId = eventId,
                CategoryId = categoryId,
                EmergencyContact = emergencyContact,
                MedicalAidNumber = string.IsNullOrWhiteSpace(medicalAidNumber) ? null : medicalAidNumber
            };

            var response = await client.PostAsJsonAsync("api/enrolments", payload);

            if (response.IsSuccessStatusCode)
            {
                TempData["Success"] = "Successfully enrolled!";
                return RedirectToAction("MyEnrolments");
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            var apiError = await response.Content.ReadAsStringAsync();
            TempData["Error"] = $"Enrolment failed. {apiError}";

            return RedirectToAction("Details", "Events", new { id = eventId });
        }
    }
}