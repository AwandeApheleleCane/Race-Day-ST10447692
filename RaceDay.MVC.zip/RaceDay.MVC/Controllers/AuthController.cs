﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Net.Http.Json; // Required for PostAsJsonAsync

namespace RaceDay.MVC.Controllers
{
    public class AuthController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public AuthController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var client = _httpClientFactory.CreateClient("RaceDayApi");

            // Sends data securely in the JSON body to match the API's [FromBody]
            var loginPayload = new { Email = model.Email, Password = model.Password };
            var response = await client.PostAsJsonAsync("api/auth/login", loginPayload);

            if (response.IsSuccessStatusCode)
            {
                var authData = await response.Content.ReadFromJsonAsync<AuthResponseDto>();

                if (authData != null)
                {
                    HttpContext.Session.SetString("Token", authData.Token ?? "");
                    HttpContext.Session.SetString("UserRole", authData.Role ?? "");
                    HttpContext.Session.SetString("UserEmail", authData.Email ?? "");

                    // Use the database FirstName, falling back to email prefix if blank
                    var displayName = !string.IsNullOrWhiteSpace(authData.FirstName)
                        ? authData.FirstName
                        : (authData.Email?.Split('@')[0] ?? "Organiser");

                    HttpContext.Session.SetString("UserName", displayName);

                    // Redirect based on role
                    if (authData.Role == "Organiser")
                        return RedirectToAction("Dashboard", "Organiser");
                    else
                        return RedirectToAction("Index", "Home");
                }
            }

            var errorResponse = await response.Content.ReadAsStringAsync();
            ViewBag.Error = $"Login failed: {errorResponse}";
            return View(model);
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var client = _httpClientFactory.CreateClient("RaceDayApi");

            // Sends data securely in the JSON body
            var registerPayload = new
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Password = model.Password,
                Role = model.Role
            };

            var response = await client.PostAsJsonAsync("api/auth/register", registerPayload);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Login");
            }

            var errorResponse = await response.Content.ReadAsStringAsync();
            ViewBag.Error = $"Registration failed: {errorResponse}";
            return View(model);
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }

    // Data Transfer Object to catch the API's JSON response
    public class AuthResponseDto
    {
        public string? Token { get; set; }
        public string? Role { get; set; }
        public string? Email { get; set; }
        public string? FirstName { get; set; } // Catches Organiser's first name from database
        public string? LastName { get; set; }  // Catches Organiser's last name from database
    }
}