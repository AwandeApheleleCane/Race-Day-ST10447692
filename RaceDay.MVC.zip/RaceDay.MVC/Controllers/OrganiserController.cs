﻿using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.IO; // REQUIRED for FileStream and Path operations

namespace RaceDay.MVC.Controllers
{
    public class OrganiserController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public OrganiserController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        private bool IsOrganiser()
        {
            var role = HttpContext.Session.GetString("UserRole");
            var token = HttpContext.Session.GetString("Token");
            return role == "Organiser" && !string.IsNullOrEmpty(token);
        }

        private HttpClient GetSecureClient()
        {
            var client = _httpClientFactory.CreateClient("RaceDayApi");
            var token = HttpContext.Session.GetString("Token");
            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }
            return client;
        }

        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");

            var client = GetSecureClient();
            var events = new List<EventViewModel>();

            var response = await client.GetAsync("api/events");
            if (response.IsSuccessStatusCode)
            {
                events = await response.Content.ReadFromJsonAsync<List<EventViewModel>>() ?? new List<EventViewModel>();
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                ViewBag.Error = "Could not load events. Ensure the API is running.";
            }

            return View(events);
        }

        [HttpGet]
        public async Task<IActionResult> ManageEvents()
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");

            var client = GetSecureClient();
            var events = new List<EventViewModel>();

            var response = await client.GetAsync("api/events");
            if (response.IsSuccessStatusCode)
            {
                events = await response.Content.ReadFromJsonAsync<List<EventViewModel>>() ?? new List<EventViewModel>();
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }
            else
            {
                ViewBag.Error = "Could not load events from the API.";
            }

            return View(events);
        }

        [HttpGet]
        public IActionResult CreateEvent()
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");
            return View(new CreateEventViewModel { EventDate = DateTime.Today.AddDays(30) });
        }

        [HttpPost]
        public async Task<IActionResult> CreateEvent(CreateEventViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            string? imageUrl = null;

            // 1. Process the image upload if a file was selected
            if (model.ImageFile != null && model.ImageFile.Length > 0)
            {
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.ImageFile.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.ImageFile.CopyToAsync(stream);
                }
                imageUrl = fileName;
            }

            // 2. Build the payload for the API
            var payload = new
            {
                Title = model.Title,
                EventType = model.EventType,
                EventDate = model.EventDate,
                StartTime = model.StartTime,
                Location = model.Location,
                Province = model.Province,
                Description = model.Description,
                ImageUrl = imageUrl
            };

            var client = GetSecureClient();
            var response = await client.PostAsJsonAsync("api/events", payload);

            if (response.IsSuccessStatusCode) return RedirectToAction("Dashboard");

            ViewBag.Error = "Failed to create event in API.";
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> EditEvent(int id)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");
            var client = GetSecureClient();

            var response = await client.GetAsync($"api/events/{id}");
            if (response.IsSuccessStatusCode)
            {
                // FIXED: Read into EventViewModel first to capture ImageUrl, then map to EditEventViewModel
                var apiEvent = await response.Content.ReadFromJsonAsync<EventViewModel>();
                if (apiEvent != null)
                {
                    var editModel = new EditEventViewModel
                    {
                        EventId = apiEvent.EventId,
                        Title = apiEvent.Title,
                        EventDate = apiEvent.EventDate,
                        Location = apiEvent.Location,
                        Description = apiEvent.Description,
                        Status = apiEvent.Status,
                        ExistingImageUrl = apiEvent.ImageUrl // Map the current image over
                    };
                    return View(editModel);
                }
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            TempData["Error"] = "Could not load event for editing.";
            return RedirectToAction("Dashboard");
        }

        [HttpPost]
        public async Task<IActionResult> EditEvent(EditEventViewModel model)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");
            if (!ModelState.IsValid) return View(model);

            // FIXED: Start with the existing image
            string? finalImageUrl = model.ExistingImageUrl;

            // If the user uploaded a new image, save it and override the filename
            if (model.ImageFile != null && model.ImageFile.Length > 0)
            {
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.ImageFile.FileName);
                var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await model.ImageFile.CopyToAsync(stream);
                }
                finalImageUrl = fileName;
            }

            var client = GetSecureClient();

            // FIXED: Include the finalImageUrl in the payload
            var editPayload = new
            {
                EventId = model.EventId,
                Title = model.Title,
                EventDate = model.EventDate,
                Location = model.Location,
                Description = model.Description,
                Status = model.Status,
                ImageUrl = finalImageUrl
            };

            var response = await client.PutAsJsonAsync($"api/events/{model.EventId}", editPayload);

            if (response.IsSuccessStatusCode) return RedirectToAction("Dashboard");

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            ViewBag.Error = $"Failed. Status: {(int)response.StatusCode}. API says: {await response.Content.ReadAsStringAsync()}";
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!IsOrganiser()) return RedirectToAction("Login", "Auth");

            var client = GetSecureClient();
            var response = await client.DeleteAsync($"api/events/{id}");

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                HttpContext.Session.Clear();
                return RedirectToAction("Login", "Auth");
            }

            if (!response.IsSuccessStatusCode)
            {
                TempData["Error"] = $"Cannot delete event. It may have active enrolments. API says: {await response.Content.ReadAsStringAsync()}";
            }

            return RedirectToAction("Dashboard");
        }
    }
}