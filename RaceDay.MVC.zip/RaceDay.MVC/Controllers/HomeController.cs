using Microsoft.AspNetCore.Mvc;
using RaceDay.MVC.Models;

namespace RaceDay.MVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public HomeController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index(string searchString)
        {
            var client = _httpClientFactory.CreateClient("RaceDayApi");
            var events = new List<EventViewModel>();

            try
            {
                // Automatically downloads and maps the JSON to your C# model
                events = await client.GetFromJsonAsync<List<EventViewModel>>("api/events") ?? new List<EventViewModel>();

                // Applies the search filter if the user typed something
                if (!string.IsNullOrEmpty(searchString))
                {
                    events = events.Where(e =>
                        (e.Title != null && e.Title.Contains(searchString, StringComparison.OrdinalIgnoreCase)) ||
                        (e.Location != null && e.Location.Contains(searchString, StringComparison.OrdinalIgnoreCase))
                    ).ToList();
                }
            }
            catch (Exception)
            {
                // Prevents the app from crashing if the API is offline
                ViewBag.Error = "Could not load events. Ensure the API is running.";
            }

            return View(events);
        }
    }
}