﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http; // Required for IFormFile

namespace RaceDay.MVC.Models
{
    public class EventViewModel
    {
        public int EventId { get; set; }
        public string? Title { get; set; }
        public string? EventType { get; set; }
        public DateTime EventDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public string? Location { get; set; }
        public string? Province { get; set; }
        public string? Description { get; set; }
        public string? Status { get; set; }

        // Property to hold the image filename
        public string? ImageUrl { get; set; }

        // NEW: Property to catch the number of enrolled participants for the Manage Events page
        public int ParticipantCount { get; set; }

        // RESTORED: This is strictly required so your Enrolment dropdown catches the API data!
        public List<CategoryViewModel> Categories { get; set; } = new();
    }

    public class CreateEventViewModel
    {
        [Required] public string? Title { get; set; }
        [Required] public string? EventType { get; set; }
        [Required] public DateTime EventDate { get; set; }
        [Required] public TimeSpan StartTime { get; set; }
        [Required] public string? Location { get; set; }
        [Required] public string? Province { get; set; }
        [Required] public string? Description { get; set; }

        // Catches the uploaded file from the Create form
        public IFormFile? ImageFile { get; set; }
    }

    public class EditEventViewModel
    {
        public int EventId { get; set; }
        [Required] public string? Title { get; set; }
        [Required] public DateTime EventDate { get; set; }
        [Required] public string? Location { get; set; }
        [Required] public string? Description { get; set; }
        [Required] public string? Status { get; set; }

        // For uploading a new image, and keeping track of the old one in the Edit form
        public IFormFile? ImageFile { get; set; }
        public string? ExistingImageUrl { get; set; }
    }
}