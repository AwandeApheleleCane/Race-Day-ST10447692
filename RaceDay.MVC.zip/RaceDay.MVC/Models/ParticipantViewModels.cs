﻿namespace RaceDay.MVC.Models
{
    public class CategoryViewModel
    {
        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }
        public decimal DistanceKm { get; set; }
        public decimal EntryFee { get; set; }
    }

    public class EventDetailsViewModel : EventViewModel
    {
        public List<CategoryViewModel> Categories { get; set; } = new();
    }

    public class EnrolmentViewModel
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public DateTime EventDate { get; set; }
        public string? CategoryName { get; set; }
        public string? Status { get; set; }
    }
}