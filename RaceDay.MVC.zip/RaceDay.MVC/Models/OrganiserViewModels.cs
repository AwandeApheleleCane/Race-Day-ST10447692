﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.MVC.Models
{
    
}