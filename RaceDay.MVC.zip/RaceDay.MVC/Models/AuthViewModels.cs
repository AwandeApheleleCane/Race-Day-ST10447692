﻿namespace RaceDay.MVC.Models
{
    public class LoginViewModel
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }

    public class RegisterViewModel
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }
    }

    public class AuthResponse
    {
        public string? Token { get; set; }
        public string? Role { get; set; }
        public string? FirstName { get; set; } 
    }
}