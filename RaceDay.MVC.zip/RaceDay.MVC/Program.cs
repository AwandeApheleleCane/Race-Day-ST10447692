var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Configure HttpClient to talk to your Part 2 API
builder.Services.AddHttpClient("RaceDayApi", client =>
{
    // FIXED: Point directly to the secure HTTPS port to prevent the redirect from dropping the token
    var apiUrl = builder.Configuration["ApiBaseUrl"] ?? "https://localhost:7016";
    client.BaseAddress = new Uri(apiUrl);
});

// Enable Session Management for Role & Auth state
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddHttpContextAccessor();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseSession(); // Must be before UseAuthorization
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();