using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using RaceDay.API.Data;

namespace RaceDay.API.Tests
{
    public class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                // Remove the real database
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<RaceDayContext>));

                if (descriptor != null)
                    services.Remove(descriptor);

                // Add In-Memory database for testing
                services.AddDbContext<RaceDayContext>(options =>
                {
                    options.UseInMemoryDatabase("RaceDayTestDb");
                });
            });
        }
    }
}