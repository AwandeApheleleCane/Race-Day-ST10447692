﻿using System.Net.Http.Json;

namespace RaceDay.API.Tests
{
    public class RoleAccessTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly HttpClient _client;

        public RoleAccessTests(CustomWebApplicationFactory factory)
        {
            _client = factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                HandleCookies = true
            });
        }

        private async Task LoginAs(string email, string password)
        {
            var loginDto = new { Email = email, Password = password };
            await _client.PostAsJsonAsync("/api/auth/login", loginDto);
        }

        [Fact]
        public async Task Participant_CannotCreateEvent_ReturnsForbidden()
        {
            // Register + login as Participant first
            // Then try to call POST /api/events
            // Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task Organiser_CanCreateEvent_ReturnsCreated()
        {
            // Register + login as Organiser
            // Call POST /api/events with Distance + EventType
            // Assert success
        }
    }
}