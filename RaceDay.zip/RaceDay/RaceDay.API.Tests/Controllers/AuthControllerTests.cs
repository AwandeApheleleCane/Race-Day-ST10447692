﻿using Microsoft.AspNetCore.Mvc.Testing;
using RaceDay.API.DTOs;
using System.Net;
using System.Net.Http.Json;
using Xunit;

namespace RaceDay.API.Tests
{
    public class AuthControllerTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly HttpClient _client;

        public AuthControllerTests(CustomWebApplicationFactory factory)
        {
            _client = factory.CreateClient(new WebApplicationFactoryClientOptions
            {
                AllowAutoRedirect = false,
                HandleCookies = true
            });
        }

        [Fact]
        public async Task Register_ValidOrganiser_ReturnsCreated()
        {
            var dto = new RegisterDto
            {
                Email = "organiser@test.com",
                Password = "Password123!",
                FirstName = "Thabo",
                LastName = "Mokoena",
                Role = "Organiser"
            };

            var response = await _client.PostAsJsonAsync("/api/auth/register", dto);

            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        }

        [Fact]
        public async Task Register_DuplicateEmail_ReturnsConflict()
        {
            var dto = new RegisterDto
            {
                Email = "duplicate@test.com",
                Password = "Password123!",
                FirstName = "Test",
                LastName = "User",
                Role = "Participant"
            };

            await _client.PostAsJsonAsync("/api/auth/register", dto);
            var response = await _client.PostAsJsonAsync("/api/auth/register", dto);

            Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
        }

        [Fact]
        public async Task Login_ValidCredentials_ReturnsOk()
        {
            // First register
            var registerDto = new RegisterDto
            {
                Email = "login@test.com",
                Password = "Password123!",
                FirstName = "Lerato",
                LastName = "Dlamini",
                Role = "Participant"
            };
            await _client.PostAsJsonAsync("/api/auth/register", registerDto);

            // Then login
            var loginDto = new LoginDto
            {
                Email = "login@test.com",
                Password = "Password123!"
            };

            var response = await _client.PostAsJsonAsync("/api/auth/login", loginDto);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task Login_InvalidPassword_ReturnsUnauthorized()
        {
            var loginDto = new LoginDto
            {
                Email = "doesnotexist@test.com",
                Password = "WrongPassword"
            };

            var response = await _client.PostAsJsonAsync("/api/auth/login", loginDto);

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async Task Me_WithoutLogin_ReturnsUnauthorized()
        {
            var response = await _client.GetAsync("/api/auth/me");

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }
    }
}