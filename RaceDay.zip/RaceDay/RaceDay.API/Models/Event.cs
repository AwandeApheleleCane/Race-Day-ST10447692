﻿namespace RaceDay.API.Models
{
    public class Event
    {
        public int EventId { get; set; }
        public int OrganiserId { get; set; }
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = null!;
        public string Province { get; set; } = null!;
        public decimal Distance { get; set; }               // Required by lecturer
        public string EventType { get; set; } = null!;      // "Run", "Walk" or "Cycle"
        public string Status { get; set; } = "Draft";
        public int? MaxParticipants { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public User Organiser { get; set; } = null!;
        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }
}