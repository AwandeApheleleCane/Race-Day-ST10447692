﻿namespace RaceDay.API.Models
{
    public class Result
    {
        public int ResultId { get; set; }
        public int EnrolmentId { get; set; }
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string Status { get; set; } = "Finished";
        public DateTime RecordedAt { get; set; } = DateTime.UtcNow;
        public int RecordedBy { get; set; }

        public Enrolment Enrolment { get; set; } = null!;
        public User RecordedByUser { get; set; } = null!;
    }
}