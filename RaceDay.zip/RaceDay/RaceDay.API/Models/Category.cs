﻿namespace RaceDay.API.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public int EventId { get; set; }
        public string Name { get; set; } = null!;
        public decimal DistanceKm { get; set; }
        public decimal EntryFee { get; set; }
        public int? MaxEntries { get; set; }
        public int? AgeMin { get; set; }
        public int? AgeMax { get; set; }

        public Event Event { get; set; } = null!;
        public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
    }
}